//
//  HeaderView.h
//  WowGuild
//
//  Created by Charles Fulton on 7/16/12.
//  Copyright (c) 2012 Charlie Fulton. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeaderView : UICollectionReusableView

@property (nonatomic, weak) IBOutlet UILabel *classTypeName;

@end
