//
//  SetttingsViewController.h
//  WowGuild
//
//  Created by Charles Fulton on 8/13/12.
//  Copyright (c) 2012 Charlie Fulton. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SetttingsViewController : UIViewController

@property(weak, nonatomic) IBOutlet UITextField *guildName;
@property(weak, nonatomic) IBOutlet UITextField *realmName;

@end
