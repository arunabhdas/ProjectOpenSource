#import <UIKit/UIKit.h>

@interface CharacterViewController : UICollectionViewController
    <UICollectionViewDataSource,
    UICollectionViewDelegate,
    UIPopoverControllerDelegate>
@end
